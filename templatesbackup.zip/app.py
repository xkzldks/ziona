#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import json
import time
import os
import account
from random import *
from flask import Flask, url_for, render_template, request, redirect, session, jsonify, flash, send_file
from datetime import datetime
from model2 import db
from bson.objectid import ObjectId

now = datetime.now()
app = Flask(__name__)
# account app import
app.register_blueprint(account.blue_account)

# 파일 업로드 위치
app.config['UPLOAD_FOLDER'] = 'static/upload/'


def people_calc(n):
    print("#####people_calc#####")
    print(n)  # 저장하려는 명단

    ManCount = 0
    WomanCount = 0

    for _ in n:
        person = list(db.peopleList.find({"이름": _}, {'_id': False}))
        print(person)
        if person[0]['성별'] == list('여'):
            WomanCount += 1
        elif person[0]['성별'] == list('남'):
            ManCount += 1
    result = "남 : ", str(ManCount), "<br>여 : ", str(WomanCount), "<br>합 : ", str(ManCount + WomanCount)
    print("result ", result)

    return result


@app.route('/kakao')
def kakao():
    return render_template('kaka.html')


@app.route('/indexC')
def indexC():
    return render_template('indexC.html')


@app.route('/kakao2')
def kakao2():
    return render_template('kaka2.html')


# H T M L을 주는 부분
@app.route('/')
def home():
    print('##home##')
    return render_template('index.html')


@app.route('/checkq')
def checkq():
    print('/checkq')
    return render_template('checkq.html')


@app.route('/check')
def check():
    print("##check사이트##")
    print('/check')
    return render_template('check.html')


@app.route('/chulCheck', methods=['POST'])
def chulCheck():
    print("##출석날짜존재확인##")
    print("/chulCheck")
    title_receive = request.form['title_give']
    print(title_receive)
    i = list(db.chulseck.find({'title': title_receive}, {'_id': False}))

    print("i",i)
    print(type(i))
    print(len(i))
    print('넘어온거 ', title_receive)
    try:
        if str(i[0]['year']) == now.date().strftime("%Y"):
            print("저장된거 있음")
            return jsonify({'check': i[0]})
        else:
            print(i[0]['year'], now.date().strftime("%Y"))
            print(type(i[0]['year']), type(now.date().strftime("%Y")))
    except IndexError:
        print("저장된거 없음")
        return jsonify({'check': i})


#  저장된전체명단
@app.route('/review', methods=['GET'])
def readReviews():
    print("/review_GET")
    reviews = list(db.chulseck.find({}, {'_id': False}))
    re = []
    for _ in range(len(reviews) - 1, -1, -1):
        re.append(reviews[_])
    return jsonify({'all_reviews': re})


# API 역할을 하는 부분
@app.route('/review', methods=['POST'])
def writeReview():
    print("/review_POST")
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    title_receive = request.form['title_give']
    i = list(db.chulseck.find({'title': title_receive}, {'_id': False}))
    #  print(i)
    review_receive_list = list(map(str, request.form['review_give'].split()))
    review_receive_list = sorted(review_receive_list)
    print("확인 ", review_receive_list)
    review_receive_count = list(people_calc(review_receive_list))
    list_people = str()
    list_result = str()
    for _ in review_receive_list:
        list_people += " " + _
        print("리스트 피플" + list_people)
    for _ in review_receive_count:
        list_result += " " + _
        print("리스트 결과" + list_result)
    doc = {
        'year': now.today().year,
        'title': title_receive,
        'review': list_people,
        'count': list_result  # 인원명단 + 밑에 남여합 출력하기위해
    }
    print(review_receive_list, review_receive_count)

    try:
        if str(i[0]['year']) == now.date().strftime("%Y"):
            print("저장된거 있음")
            db.chulseck.update_one({'title': title_receive}, {"$set": {'review': list_people, 'count': list_result}})
            return jsonify({'msg': '저장성공!'})
    except IndexError:
        print("저장된거 없음")
        db.chulseck.insert_one(doc)
        return jsonify({'msg': '저장성공!'})


#  명단삭제
@app.route('/dbDel', methods=['POST'])
def delReviews():
    print("/dbDel")
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    review = request.form['title_give']
    print("db del 시작")
    print(review)
    i = list(db.chulseck.find({'title': review}, {'_id': False}))
    # print(i)
    if not i:
        return jsonify({'msg': '해당하는 날짜에 저장된 데이터가 없습니다!'})
    else:
        db.chulseck.delete_one({'title': review})
    return jsonify({'msg': '삭제성공!'})


#db 인원수정
@app.route('/dbPersonChange', methods = ['POST'])
def changeDbPerson():
    print('/dbPersonChange')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    try:
        print(userAuthCheck[0])
    except IndexError:
        print("권한 없음, 비로그인")
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    name = request.form['name']
    group = request.form['group']
    s = request.form['sSelect']
    info = request.form['info']
    age = request.form['age']

    i1 = list(db.peopleList.find({'이름': name}, {'_id': False}))

    if not i1:
        return jsonify({'no': "같은 이름의 사람이 없습니다!"})
    else:
        print(i1)
        db.peopleList.update_one({'이름': name}, {"$set": {'조': [str(group)], '나이': [age],'성별': [str(s)], '특이사항': [str(info)]}})
        return jsonify({'msg': "대상 : " + name + "\n" + str(group)+ "\n" + age + "\n" + str(s)+ "\n" + str(info)+ "\n"+'저장성공!'})


#  db 인원추가
@app.route('/dbPersonAdd', methods=['POST'])
def addDbPerson():
    print('/dbPersonAdd')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    try:
        print(userAuthCheck[0])
    except IndexError:
        print("권한 없음, 비로그인")
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    name = request.form['name']
    age = request.form['age']
    group = request.form['group']
    s = request.form['sSelect']
    info = request.form['info']
    i1 = list(db.peopleList.find({'이름': name}, {'_id': False}))
    if not i1:
        doc = {
            '이름': name,
            '나이': [age],
            '조': [str(group)],
            '성별': [str(s)],
            '특이사항': [str(info)]
        }
        print(doc)
        db.peopleList.insert_one(doc)
        return jsonify({'msg': name + " " + group + " " + s + ' 저장성공!'})
    else:
        return jsonify({'no': "같은 이름의 사람이 있습니다!"})


#  db 인원삭제
@app.route('/dbPersonDel', methods=['POST'])
def delDbPerson():
    print('/dbPersonDel')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    print("#####출력#####")
    name = request.form['name']
    group = list(request.form['group'].strip().split())

    i1 = list(db.peopleList.find({'이름': name, '조': group}, {'_id': False}))
    if not i1:
        return jsonify({'no': 'DB에 저장된 인원이 없습니다!'})
    else:
        print(i1)
        print(i1[0]['조'][0])
        db.peopleList.delete_one({'이름': name, '조': group})
        print("msg: " + name + i1[0]['조'][0] + " " + ' 삭제성공!')
        return jsonify({'msg': name + " " + i1[0]['조'][0] + " " + '삭제성공!'})


@app.route('/ageAdd', methods=['POST'])
def ageAdd():
    print('/ageAdd')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    i1 = list(db.peopleList.find({},{'_id': False}))

    for i in i1:
        print(i)
        print(i['이름'], i['나이'][0])
        a = int(i['나이'][0]) + 1
        print(i['이름'], i['나이'][0], "->", a)
        db.peopleList.update_one({'이름': i['이름']},{"$set": {'나이': [a]}})
        #i['나이'] = i['나이'][0] + 1
    return jsonify({'msg': '전체인원 나이 증가!'})

@app.route('/ageDown', methods=['POST'])
def ageDown():
    print('/ageDown')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    i1 = list(db.peopleList.find({}, {'_id': False}))

    for i in i1:
        print(i)
        print(i['이름'], i['나이'][0])
        a = int(i['나이'][0]) - 1
        print(i['이름'], i['나이'][0], "->", a)
        db.peopleList.update_one({'이름': i['이름']}, {"$set": {'나이': [a]}})
    return jsonify({'msg': '전체인원 나이 감소!'})

#  인원추가
@app.route('/personAdd', methods=['POST'])
def addPerson():
    print('/personAdd')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    review = request.form['title_give']
    addPersonList = request.form['new_give'].strip().split()
    print(addPersonList)
    print("personAdd 시작")
    i = list(db.chulseck.find({'title': review}, {'_id': False}))
    successList = ""
    failList = ""
    if not i:
        return jsonify({'msg': '해당하는 날짜에 저장된 데이터가 없습니다!'})
    else:
        print("삭제 후 db 업데이트")
        review_receive_list = list(i[0]['review'].strip().split())
        review_receive_list = sorted(review_receive_list)
        review_receive_list_copy = review_receive_list
        print(type(review_receive_list_copy))

        #addPersonList = addPersonList.split(" ")
        for _ in addPersonList:
            print(_)
            if _ == '':
                review_receive_list_copy.remove(_)
            if _ not in review_receive_list:
                review_receive_list_copy.append(_)
                successList += _ + " "
            else:
                failList += _ + " "
        print(review_receive_list)
        print(review_receive_list_copy)
        review_receive_count = people_calc(review_receive_list_copy)
        list_people = str()
        list_result = str()
        for _ in review_receive_list_copy:
            list_people += " " + _
            print("리스트 피플" + list_people)
        for _ in review_receive_count:
            list_result += " " + _
            print("리스트 결과" + list_result)
        db.chulseck.update_one({'title': review}, {"$set": {'review': list_people, 'count': list_result}})
    return jsonify({'msg': '추가된 인원 : ' + successList + "\n" '추가안된 인원 : ' + failList})


#  인원삭제
@app.route('/personDel', methods=['POST'])
def delPerson():
    print('/personDel')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    review = request.form['title_give']
    delPersonList = request.form['new_give']
    print("personDel 시작")
    i = list(db.chulseck.find({'title': review}, {'_id': False}))
    successList = ""
    failList = ""
    if not i:
        return jsonify({'msg': '해당하는 날짜에 저장된 데이터가 없습니다!'})
    else:
        print("삭제 후 db 업데이트")
        review_receive_list = list(i[0]['review'].strip().split())
        review_receive_list = sorted(review_receive_list)
        review_receive_list_copy = review_receive_list
        print(type(review_receive_list_copy))

        delPersonList = delPersonList.split(" ")
        for _ in delPersonList:
            print(_)
            if _ == '':
                review_receive_list_copy.remove(_)
            if _ in review_receive_list:
                review_receive_list_copy.remove(_)
                successList += _ + " "
            else:
                failList += _ + " "
        print(review_receive_list)
        print(review_receive_list_copy)
        review_receive_count = people_calc(review_receive_list_copy)
        list_people = str()
        list_result = str()
        for _ in review_receive_list_copy:
            list_people += " " + _
            print("리스트 피플" + list_people)
        for _ in review_receive_count:
            list_result += " " + _
            print("리스트 결과" + list_result)
        db.chulseck.update_one({'title': review}, {"$set": {'review': list_people, 'count': list_result}})
    return jsonify({'msg': '삭제된 인원 : ' + successList + "\n" '명단에 없는 인원 : ' + failList})


# 엑셀 데이터 표시
# @app.route('/review', methods=['GET'])
# def read_reviews():
#     reviews = list(db.chulseck.find({}, {'_id': False}))
#     re = []
#     for _ in reviews:
#         print(_)
#         print(_['title'])
#         for i in peo:
#             if i in _["review"]:
#                 print(1)
#             else:
#                 print("")
#     return jsonify({'all_reviews': re})



@app.route('/getCheckboxInfo', methods = ['POST'])
def getCheckboxInfo():
    print('/getCheckboxInfo')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    name = request.form['name']
    print(name)
    group = request.form['group']
    print(group)
    i1 = list(db.peopleList.find({'이름': name, '조': group}, {'_id': False}))
    print(i1)
    se = ""
    try:
        se = i1[0]['성별'][0]
        print(se)
        info = i1[0]['특이사항'][0]
        print(info)
    except IndexError or ValueError:
        info = ""

    return jsonify({"se": se, "info": info})


@app.route('/getTDate', methods=['GET'])
def getTDate():
    print('/getTDate')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    re = []
    for _ in reviews:
        re.append(str(_['year'])+" "+str(_['title']))
    print("tDate", re)
    return jsonify({"date": re})


@app.route('/getGroupGraph', methods=['GET'])
def getGroupGraph():
    print('/getGroupGraph_월전체')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    people = list(db.peopleList.find({}, {'_id': False}))
    dbGroup = list(db.Group.find({}, {'_id': False}))
    print(dbGroup)
    dbG = []

    group2 = ["" for i in range(len(dbGroup))]
    group3 = []
    for _ in dbGroup:
        dbG.append(_.get('조 이름'))
    print(dbGroup)
    print(dbG)

    for i in people:
        group2[dbG.index(i['조'][0])] += i['이름']+" "
    print("group2", group2)

    for _ in group2:
        _ = len(list(_.strip().split(" ")))
        print(_)

    dbGroup = list(dbG)
    month = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]

    # dbG = [[] for i in range(len(dbGroup))]
    # print(dbG)

    chu = []
    result = []
    # chu.append('Group')

    for i in month:
        m = i
        for _ in reviews:
            if str(_['year']) == now.date().strftime("%Y"):
                if str(_['title'])[:2] == i:
                    m += _['review']
        chu.append(m)

    print(chu) ##월별 전체인원출석현황
    r = dbG
    r.insert(0, "조이름")
    print(r)
    # result.append(dbGroup)
    for _ in chu:
        # print(_[:2])
        m = _[:2]
        group = [0 for i in range(len(dbGroup))]
        if _ != '월별':
            for i in people:
                # print(i['조'][0], _.count(i['이름']), dbGroup.index(i['조'][0]))
                group[dbGroup.index(i['조'][0])] += _.count(i['이름'])
                # print(group[dbGroup.index(i['조'][0])])
        print(group)
        group.insert(0, m+'월')
        result.append(group)
    result.insert(0, r)
    chu = result
    print(chu)
    return jsonify({"chul": chu})


@app.route('/getGroupGraph2', methods=['GET'])
def getGroupGraph2():
    print('/getGroupGraph2_월 평균')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    people = list(db.peopleList.find({}, {'_id': False}))
    dbGroup = list(db.Group.find({}, {'_id': False}))
    print(dbGroup)
    dbG = []

    group2 = ["" for i in range(len(dbGroup))]
    group3 = [] #각 그룹에 속한 사람 수
    for _ in dbGroup:
        dbG.append(_.get('조 이름'))
    print(dbGroup)
    print(dbG)

    for i in people:
        group2[dbG.index(i['조'][0])] += i['이름']+" "
    print("group2", group2)

    for _ in group2:
        _ = len(list(_.strip().split(" ")))
        print(_)
        group3.append(_)
    print("group3", group3)
    dbGroup = list(dbG)
    month = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
    month2 = [0 for i in range(len(month))]

    # dbG = [[] for i in range(len(dbGroup))]
    # print(dbG)

    chu = []
    result = []
    # chu.append('Group')

    for i in month:
        m = i
        for _ in reviews:
            if str(_['year']) == now.date().strftime("%Y"):
                if str(_['title'])[:2] == i:
                    m += _['review']
                    month2[month.index(i)] += 1
        chu.append(m)
    print("m2",month2)
    print(chu) ##월별 전체인원출석현황
    r = dbG
    r.insert(0, "조이름")
    print(r)
    # result.append(dbGroup)
    a = 0
    for _ in chu:
        a += 1
        # print(_[:2])
        m = _[:2]
        group = [0 for i in range(len(dbGroup))]
        for i in people:
            # print(i['조'][0], _.count(i['이름']), dbGroup.index(i['조'][0]))
            group[dbGroup.index(i['조'][0])] += _.count(i['이름'])
            # print(group[dbGroup.index(i['조'][0])])
            if i == people[-1]:
                print(a, group, sum(group))
                gSum = sum(group)
                for k in range(len(group)):
                    # group[k] /= group3[k] * month2[k] #각 월별 조 출석인원 / 그 조의 전체 인원 * 해당 월의 출석주차수
                    print("group", dbGroup[k], group[k], gSum)
                    try:
                        group[k] /= gSum # 해당 월의 조 출석인원 / 전체 출석인원
                    except ZeroDivisionError:
                        group[k] = 0
                    group[k] *= 100
                # group[dbGroup.index(i['조'][0])] = (group[dbGroup.index(i['조'][0])]/group3[dbGroup.index(i['조'][0])])
        print(group)
        group.insert(0, m+'월')
        result.append(group)
    result.insert(0, r)
    chu = result
    print(chu)
    return jsonify({"chul": chu})

@app.route('/getAgeGraph', methods=['GET'])
def getAgeGraph():
    print('/getAgeGraph')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    people = list(db.peopleList.find({}, {'_id': False}))
    ageGroup = []
    month = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
    month2 = [0 for i in range(len(month))]

    for i in people:
        ageGroup.append(i['나이'][0])

    ageGroupS = set(ageGroup)
    print(ageGroupS)
    ageGroupS = list(sorted(ageGroupS))
    print(type(ageGroupS))

    r = ageGroup
    r.insert(0, "나이")

    a = 0
    chu = []
    result = []

    for i in month:
        m = i
        for _ in reviews:
            if str(_['year']) == now.date().strftime("%Y"):
                if str(_['title'])[:2] == i:
                    m += _['review']
                    month2[month.index(i)] += 1
        chu.append(m)

    for _ in chu:
        a += 1
        # print(_[:2])
        m = _[:2]
        group = [0 for i in range(len(ageGroupS))]
        for i in people:
            # print(i['조'][0], _.count(i['이름']), dbGroup.index(i['조'][0]))
            group[ageGroupS.index(i['나이'][0])] += _.count(i['이름'])
            # print(group[dbGroup.index(i['조'][0])])
            if i == people[-1]:
                print(a, group, sum(group))
                gSum = sum(group)
                for k in range(len(group)):
                    # group[k] /= group3[k] * month2[k] #각 월별 조 출석인원 / 그 조의 전체 인원 * 해당 월의 출석주차수
                    print("group", ageGroupS[k], group[k], gSum)
                    try:
                        group[k] /= gSum  # 해당 월의 조 출석인원 / 전체 출석인원
                    except ZeroDivisionError:
                        group[k] = 0
                    group[k] *= 100
                # group[dbGroup.index(i['조'][0])] = (group[dbGroup.index(i['조'][0])]/group3[dbGroup.index(i['조'][0])])
        print(group)
        group.insert(0, m + '월')
        result.append(group)
    print("re",result)
    ageGroupS.insert(0,'나이')
    result.insert(0, ageGroupS)
    chu = result
    print(chu)
    return jsonify({"chul": chu})


@app.route('/getAttendanceGraph', methods=['GET'])
def getAttendanceGraph():
    print('/getAttendanceGraph')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    people = list(db.peopleList.find({}, {'_id': False}))
    re =[]
    str = ""
    chul = {}
    chu = []

    for i in reviews:
        str += i['review']

    str = list(str.strip().split(" "))

    for _ in people:
        try:
            if str.count(_['이름']) > 0:
                chu.append([_['이름'], str.count(_['이름'])])
                chul[_['이름']] = str.count(_['이름'])
        except KeyError:
            print("x")

    bubble_sort_chul(chu)
    chul2 = dict(sorted(chul.items(), key=lambda x: x[1], reverse=True)) #람다정렬
    print(chul2)
    print(chu)
    chu2 = chu
    # for i in people:
    #     print(chu[i])
    #     print(chu[i][0], chu[i][1])
    #     if chu[i][1] == 0:
    #         print("true")
    #         print(chu[i])
    #         chu2.remove(chu[i])
    #         print(chu2[i][0], chu2[i][1])
    # print(chu2)
    return jsonify({"chul": chu})


@app.route('/getTChul', methods= ['GET'])
def getTChul():
    print('/getTChul')
    reviews = list(db.chulseck.find({}, {'_id': False}))
    people = list(db.peopleList.find({}, {'_id': False}))
    bubble_sort(people)
    chul = []

    for i in people:
        re = []
        cnt = 0
        re.append(i['이름'])
        for _ in reviews:
            if i['이름'] in _['review']:
                re.append("1")
                cnt += 1
            else:
                re.append(".")
        per = str(int(cnt/len(reviews)*100)) + str("%")
        re.insert(1, per)
        chul.append(re)
    return jsonify({'chul': chul})


def bubble_sort_chul(arr):
    for i in range(len(arr) - 1, 0, -1):
        for j in range(i):
            if arr[j][1] < arr[j + 1][1]:
                arr[j][0], arr[j + 1][0] = arr[j + 1][0], arr[j][0]
                arr[j][1], arr[j + 1][1] = arr[j + 1][1], arr[j][1]



@app.route('/getGroup', methods=['GET'])
def getGroup():
    print('/getGroup')
    dbGroup = list(db.Group.find({}, {'_id': False}))
    print(dbGroup)
    return jsonify({'dbG': dbGroup})


@app.route('/getTxtGroup', methods=['GET'])
def getGroup2():
    print('/getTxtGroup')
    dbGroup = list(db.Group.find({}, {'_id': False}))
    print(dbGroup)
    return jsonify({'dbG': dbGroup})


#  명단체크박스출력
@app.route('/getDB', methods=['GET'])
def readPeopleDB():
    print('/getDB')
    dbGroup = list(db.Group.find({}, {'_id': False}))
    dbPeople = list(db.peopleList.find({}, {'_id': False}))
    l = []
    for _ in range(len(dbGroup)):
        s = []
        for i in dbPeople:
            #  print(list(dbGroup[_ ].values()))
            if i['조'] == list(dbGroup[_].values()):
                s.append(i)
            if i == dbPeople[-1]:
                bubble_sort(s)
                l.extend(s)
                s = []

    global n
    n = []
    for _ in dbPeople:
        if _ not in l:
            n.append(_)
    bubble_sort(n)
    print("n ",len(n))
    print("소속 x ", n)
    print("소속 o ", l)
    return jsonify({'dbP': l, 'dbG': dbGroup})


#  명단체크박스출력_미분류그룹
@app.route('/getNotsetGroup', methods=['GET'])
def readNotSetPeopleDB():
    print("/getNotsetGroup")
    print("넘어옴!")
    print("소속 x ", n)
    return jsonify({'dbP': n})


def bubble_sort(arr):
    for i in range(len(arr) - 1, 0, -1):
        for j in range(i):
            if arr[j]['이름'] > arr[j + 1]['이름']:
                arr[j]['이름'], arr[j + 1]['이름'] = arr[j + 1]['이름'], arr[j]['이름']
                arr[j]['나이'], arr[j + 1]['나이'] = arr[j + 1]['나이'], arr[j]['나이']
                arr[j]['조'], arr[j + 1]['조'] = arr[j + 1]['조'], arr[j]['조']
                arr[j]['성별'], arr[j + 1]['성별'] = arr[j + 1]['성별'], arr[j]['성별']
                arr[j]['특이사항'], arr[j + 1]['특이사항'] = arr[j + 1]['특이사항'], arr[j]['특이사항']


#  결과복사_데이터확인
@app.route('/copyResult', methods=['POST'])
def copyResultPOST():
    print("/copyResultPost")
    review = request.form['title_give']
    global sendResult
    sendResult = list(db.chulseck.find({'title': review}, {'_id': False}))
    print(sendResult)
    if not sendResult:
        return jsonify({'msg': '해당하는 날짜에 저장된 데이터가 없습니다!'})
    else:
        print(sendResult[0]['title'])
        print(sendResult[0]['review'])
        print(sendResult[0]['count'])
        return jsonify({'review': sendResult})


@app.route('/changeGroupU', methods=['POST'])
def changeGroup():
    print("/changeGroupU")
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    peopleList = list(request.form['peopleList'].strip().split(' '))
    print(peopleList)
    print(len(peopleList))
    nextGroup = request.form['new_give']
    print(nextGroup)
    for _ in peopleList:
        print(_, nextGroup)
        db.peopleList.update_one({'이름': _}, {"$set": {'조': [nextGroup]}})
    return jsonify({'msg': 'txt'})


@app.route('/setGroup', methods=['POST'])
def setGroup():
    print("/setGroup")
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    groupList = list(request.form['strGroup'].strip().split(' '))
    groupList = [v for v in groupList if v]
    strGroupList = str()
    print(groupList)
    print(len(groupList))

    db.Group.drop()
    # txt = "조 변경 성공!"
    for _ in groupList:
        doc = {
            "조 이름": _
        }
        db.Group.insert_one(doc)
        strGroupList += _ + "\n"
    return jsonify({'msg': strGroupList + "그룹 변환 성공"})

#  결과복사_데이터전송
@app.route('/copyResult', methods=['GET'])
def copyResultGet():
    print('/copyResultGet')
    try:
        r = str(sendResult[0]['year']) + " " + str(sendResult[0]['title']) + '\n' + str(sendResult[0]['review']) \
            + '\n' + str(sendResult[0]['count'])
        r = r.replace("      ", " ")
        print(r)
        return jsonify({'review': r})
    except IndexError:
        r = "날짜를 확인해주세요."
        return jsonify({'review': r})


@app.route('/getUserAuth', methods=['GET'])
def getUserAuth():
    print('/getUserAuth')
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))

    # if not i:
    #     i = 0
    # else:
    #     i = userAuthCheck[0]['auth']
    i = 0
    try:
        i = userAuthCheck[0]['auth']

    except IndexError:
        i = 0
    print("권한 ", i)
    return jsonify({'msg': i})


#  그래프출력
@app.route("/graph")
def graph():
    return render_template('graph3.html')


@app.route("/login")
def login():
    return render_template('login.html')


#########게시판#############

def filesave(file):
    d_num = 1
    filename = file.filename
    file_path = app.config['UPLOAD_FOLDER'] + filename

    # 중복파일이 없을때 까지 파일명 수정
    print(file_path, os.path.isfile(file_path))
    while os.path.isfile(file_path):
        filename = str(d_num) + "_" + file.filename
        d_num += 1
        file_path = app.config['UPLOAD_FOLDER'] + filename

    file.save(file_path)
    return filename

@app.route('/write', methods=['GET', 'POST'])
def write():
    username = session.get("username")
    if not username:
        flash("로그인부터 해주세요")
        return redirect(url_for('account.login'))

    if request.method == 'POST':
        title = request.form['title']
        content = request.form.get('content')
        create_date = str(time.strftime("%Y.%m.%d", time.localtime()))

        if title and content:
            print(title)
            print(content)
            # 파일 업로드
            files = request.files.getlist("file[]")
            images = []
            # 파일 유무 확인
            print("filename", files[0].filename)
            if not files[0].filename == "":
                # upload 폴더 생성(기존에 있으면 생성x)
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

                for file in files:
                    filename = filesave(file)
                    print(filename)
                    images.append({"filename": filename})

            board = {
                "title": title,
                "content": content,
                "create_date": create_date,
                "username": username,
                "hit": 0,
                "good": [],
                "bad": [],
                "images": images
            }
            board_id = db.board.insert_one(board).inserted_id
            print(board)
            flash('작성 완료!')
            return redirect(url_for('detail', board_id=board_id))

        else:
            flash('제목과 내용을 빈칸없이 입력해주세요')
            # return render_template('board_in.html')
    return render_template('board_in.html')



@app.route('/board')
def board():
    boards = list(db.board.find({}).sort([("_id", -1)]))
    max_page = len(boards) // 10 + 1
    # 한 페이지에 들어가는 게시글 개수
    page_block = 10

    # 현재 페이지
    num = request.args.get('page')
    print("num", num)
    # 만약 처음 게시판 접속했을땐 페이지번호 = 1
    num = int(num) if num else 1

    # 이전 페이지 접속(페이지번호가 1보다 작을때) 했을때 페이지 번호 조정
    if num < 1: num = 1
    # 페이지 번호는 5개씩 보여줌
    start_page = ((num - 1) // 5) * 5 + 1  # 페이지 시작 번호
    end_page = start_page + 4 if (start_page + 4) < max_page else max_page  # 페이지 끝번호
    # 다음 페이지 접속(페이지 번호가 페이지 끝번호보다 클때)
    if num > end_page: num = end_page
    board_num = len(boards) - (page_block * (num - 1))
    return render_template('board.html', boards=boards[page_block * (num - 1): page_block * num], page=num,
                           board_num=board_num, start_page=start_page, end_page=end_page)


@app.route('/modify/<board_id>', methods=['GET', 'POST'])
def modify(board_id):
    username = session.get("username")
    if not username:
        flash("로그인부터 해주세요")
        return redirect(url_for('account.login'))

    board = db.board.find_one({'_id': ObjectId(board_id)})
    if request.method == 'POST':
        title = request.form['title']
        content = request.form.get('content')

        if title and content:
            print(title)
            print(content)

            # 기존 파일 삭제
            print("product images : ", board['images'])
            for image in board['images']:
                print("iamge: ", image)
                file_path = app.config['UPLOAD_FOLDER'] + image['filename']
                if os.path.isfile(file_path):
                    os.remove(file_path)

            # 파일 업로드
            files = request.files.getlist("file[]")
            images = []
            # 파일 유무 확인
            print("filename", files[0].filename)
            if not files[0].filename == "":
                # upload 폴더 생성(기존에 있으면 생성x)
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

                for file in files:
                    filename = filesave(file)
                    print(filename)
                    images.append({"filename": filename})

            board = {
                "title": title,
                "content": content,
                "images": images
            }
            db.board.update_one({'_id': ObjectId(board_id)}, {"$set": board})
            flash('수정 완료!')
            return redirect(url_for('detail', board_id=board_id))
        else:
            flash('다시 입력해주세요')
            return render_template('modify.html', board=board)
    print(board)
    return render_template('modify.html', board=board)


@app.route('/detail/<board_id>')
def detail(board_id):
    # board_id = request.args.get('board')
    print("detail board id", board_id)

    db.board.update_one({'_id': ObjectId(board_id)}, {"$inc": {"hit": 1}})
    board = db.board.find_one({'_id': ObjectId(board_id)})

    print("detail", board)
    return render_template('detail.html', board=board)


@app.route('/delete/<board_id>')
def delete(board_id):
    board = db.board.find_one({'_id': ObjectId(board_id)})
    # 기존 파일 삭제
    print("product images : ", board['images'])
    for image in board['images']:
        print("iamge: ", image)
        file_path = app.config['UPLOAD_FOLDER'] + image['filename']
        if os.path.isfile(file_path):
            os.remove(file_path)
    db.board.delete_one({'_id': ObjectId(board_id)})

    flash('삭제 완료!')
    return redirect(url_for('board'))

@app.template_filter("formatdatetime")
def format_datetime(value):
    if value is None:
        return ""

    now_timestamp = time.time()
    offset = datetime.fromtimestamp(now_timestamp) - datetime.utcfromtimestamp(now_timestamp)
    value = datetime.fromtimestamp(int(value / 1000)) + offset
    return value.strftime('%Y-%m-%d %H:%M:%S')


@app.route('/filedown/<filename>')
def filedown(filename):
    file_path = app.config['UPLOAD_FOLDER'] + filename
    return send_file(file_path, as_attachment=True)


@app.route('/good/<board_id>')
def good(board_id):
    username = session.get("username")
    if not username:
        return jsonify({"success": False, "msg": "로그인 후 이용가능합니다."})

    try:
        board = db.board.find_one({"$and": [{'good': username}, {'_id': ObjectId(board_id)}]})
        print(board)
        print("good board", board)
        if board:
            db.board.update_one({'_id': ObjectId(board_id)}, {"$pull": {"good": username}})
            # print(board)
            return jsonify({"success": True, "is_good": False})
        else:
            db.board.update_one({'_id': ObjectId(board_id)}, {"$push": {"good": username}})
            # print(board['good'])
            return jsonify({"success": True, "is_good": True})
    except Exception as e:
        print(e)
        return jsonify({"success": False, "msg": "잘못된 요청입니다."})


@app.route('/bad/<board_id>')
def bad(board_id):
    username = session.get("username")
    if not username:
        return jsonify({"success": False, "msg": "로그인 후 이용가능합니다."})

    try:
        board = db.board.find_one({"$and": [{'bad': username}, {'_id': ObjectId(board_id)}]})

        if board:
            db.board.update_one({'_id': ObjectId(board_id)}, {"$pull": {"bad": username}})
            return jsonify({"success": True, "is_bad": False})
        else:
            db.board.update_one({'_id': ObjectId(board_id)}, {"$push": {"bad": username}})
            return jsonify({"success": True, "is_bad": True})
    except:
        return jsonify({"success": False, "msg": "잘못된 요청입니다."})


@app.route('/qr', methods = ["POST"])
def qrCode():
    name = request.form['name']
    gender = request.form['gender']
    birthday = request.form['birthday']
    person = ""

    person = list(db.peopleList.find({"이름": name}, {'_id': False}))

    print(person)
    dM = str(datetime.today().month)
    dD = str(datetime.today().day)
    if int(dM) < 10:
        dM = "0" + str(datetime.today().month)

    if int(dD) < 10:
        dD = "0" + str(datetime.today().day)
    try:
        qr = {
            "year": now.date().strftime("%Y"),
            "title": dM+dD,
            "이름": name,
            "조": person[0]['조'][0],
            "r": randint(1, 100)
        }
        qr2 = "year : " + str(now.date().strftime("%Y")) + "\ntitle : " + dM+dD + "\n이름 : " + name + "\n조 : " + person[0]['조'][0] + "\nr : " + str(randint(1, 100))
        print("qr", qr, "qr2", qr2)
    except IndexError:
        return jsonify({"msg": "명단에 이름이 없습니다. 서기나 임원들에게 문의부탁드립니다."})

    return jsonify({"msg": qr, "qr2": str(qr2)})


@app.route('/qrChul', methods= ["POST"])
def qrChul():
    userAuthCheck = list(db.user.find({'username': session.get("username")}, {'_id': False}))
    if not session.get("username"):
        return jsonify({"False": "False"})
    elif userAuthCheck[0]['auth'] != 1:
        return jsonify({"False": "Auth"})

    re = request.form['title_give']
    result = {}
    key = []
    val = []
    re = list(re.strip().split("\n"))
    print(re)
    for _ in re:
        a = _.strip().split(":")
        key.append(a[0].replace(" ", ""))
        val.append(a[1].replace(" ", ""))
    dic = dict(zip(key, val))
    print(dic)
    try:
        a = dic['이름']
        print(a)
    except:
        return jsonify({"msg": "추가안됨"})

    i = list(db.chulseck.find({'title': dic['title']}, {'_id': False}))
    print('i', i)
    successList = ""
    failList = ""

    if not i:
        # return jsonify({'msg': '해당하는 날짜에 저장된 데이터가 없습니다!'})
        writeReviewQ(dic)
    else:
        print('else')
        print(i[0]['review'])
        print(addPerson)
        addPersonList = dic['이름']
        print("삭제 후 db 업데이트")
        review_receive_list = list(i[0]['review'].strip().split())
        review_receive_list = sorted(review_receive_list)
        review_receive_list_copy = review_receive_list
        print(type(review_receive_list_copy))

        # addPersonList = addPersonList.split(" ")
        # addPersonList = dic['이름']
        print("apl",addPersonList)
        if addPersonList == '':
            review_receive_list_copy.remove(addPersonList)
        if addPersonList not in review_receive_list:
            review_receive_list_copy.append(addPersonList)
            successList += addPersonList + " "
        else:
            failList += addPersonList + " "
            print(failList)
            return jsonify({"msg": "추가안됨"})

        print(review_receive_list)
        print(review_receive_list_copy)
        review_receive_count = people_calc(review_receive_list_copy)
        list_people = str()
        list_result = str()
        for _ in review_receive_list_copy:
            list_people += " " + _
            print("리스트 피플" + list_people)
        for _ in review_receive_count:
            list_result += " " + _
            print("리스트 결과" + list_result)
        db.chulseck.update_one({'title': dic['title']}, {"$set": {'review': list_people, 'count': list_result}})
        return jsonify({"msg": "good"})


def writeReviewQ(dic):
    print("/review_QR")
    title_receive = dic['title']
    #  print(i)
    ManCount = 0
    WomanCount = 0

    person = list(db.peopleList.find({"이름": dic['이름']}, {'_id': False}))
    print(person)
    if person[0]['성별'] == list('여'):
        WomanCount += 1
    elif person[0]['성별'] == list('남'):
        ManCount += 1
    result = "남 : ", str(ManCount), "<br>여 : ", str(WomanCount), "<br>합 : ", str(ManCount + WomanCount)
    print("result ", result)

    review_receive_count = result
    list_people = str()
    list_result = str()
    for _ in review_receive_count:
        list_result += " " + _
        print("리스트 결과" + list_result)
    doc = {
        'year': now.today().year,
        'title': dic['title'],
        'review': list_people,
        'count': list_result  # 인원명단 + 밑에 남여합 출력하기위해
    }
    print(review_receive_count)

    db.chulseck.insert_one(doc)
    return jsonify({'msg': '저장성공!'})

if __name__ == '__main__':
    app.secret_key = "123"
    app.run('0.0.0.0', debug=True)
